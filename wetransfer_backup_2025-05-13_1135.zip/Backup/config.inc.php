<?php
define('HOME', 'https://www.draevelisejarema.com.br');
define('IMG',  '/img');


$telefone1 = "41998590415";
$email = "contato@draevelisejarema.com.br";
$endereco ="Rua Emiliano Perneta 860, sala 902 – Edifício Mac Saúde <br>Curitiba - PR, CEP: 80420-080";
$link_endereco = "https://maps.app.goo.gl/EVEwZiQ5SW47K3AGA";
$facebook = "https://www.facebook.com/dentistaevelise";
$instagram = "https://www.instagram.com/draevejarema";

$getURL = strip_tags(@trim((string) filter_input(INPUT_GET, 'url', FILTER_DEFAULT)));
$setURL = (empty($getURL) ? 'index' : $getURL);
$URL = explode('/', $setURL);
$URL[1] = (empty($URL[1]) ? 'index' : $URL[1]);

// mask('## ####-####', 4100000000) = 41 0000-0000
// mask('%%% - %%%%', 'teste abcd') = 'tes - abcd'
function mask($mask_pattern, $mask_item){
    $masked = "";
    for($i = 0, $j = 0; $i < strlen($mask_pattern); $i++){
        $patternChar = $mask_pattern[$i];
        if ($j < strlen($mask_item)) { // Adicionada esta verificação
            $itemChar = $mask_item[$j];
            if($patternChar == "#" && is_numeric($itemChar)){ $masked .= $itemChar; $j++; }
            else if($patternChar == "%" && !is_numeric($itemChar)){ $masked .= $itemChar; $j++; }
            else{ $masked .= $patternChar; }
        } else {
            $masked .= $patternChar; // Se $mask_item acabou, adiciona o caractere da máscara como está
        }
    }
    return $masked;
}

function removeAcento($text){
    setlocale(LC_CTYPE, 'pt_BR.UTF-8');
    $text = strtolower($text);
    $text = preg_replace("/[ ]/", '-', $text);
    $text = iconv('UTF-8', 'ASCII//TRANSLIT', $text);
    $text = preg_replace("/[^a-zA-Z0-9-]/", '', $text);
    return strtolower($text);
}

function link_whats($telefone){
    return "https://web.whatsapp.com/send?phone=55".$telefone;
}

function loadResource($path, $startComplement=REQUIRE_PATH.'/'){
    if(is_array($path)){
        $return = true;
        foreach($path as $newPath){
            if(!loadResource($newPath)){
                $return = false;
            }
        }
        return $return;
    }

    $logInformation = "\n\tError thrown: ".__FILE__.' line: '.__LINE__;
    if(!is_string($path)){
        // error_log("There was an error while tryig to load a resource, the input was not of type String.{$logInformation}");
        return false;
    }
    
    if(strlen($path) == 0){
        // error_log("There was an error while tryig to load a resource, no input was given.{$logInformation}");
        return false;
    }

    if(substr($path, 0, 1) == '/'){
        $path = substr($path, 1);
    }

    $is_url = false;
    if(!preg_match('/http(s){0,}.*/i', $path)){
        $dir = dirname(__DIR__, 1);
        $file = "{$dir}/{$startComplement}{$path}";
        if(!file_exists($file)){
            // error_log("There was an error while loading '{$path}', the file does not exist.{$logInformation}");
            return false;
        }
    
        if(is_dir($file)){
            // error_log("There was an error while loading '{$path}', it is a folder.{$logInformation}");
            return false;
        }
    
        $file_href = INCLUDE_PATH . "/{$path}";
    } else {
        $is_url = true;
        $file_href = "{$path}";
    }

    $exp = explode('/', $path);
    $exp = $exp[count($exp)-1];

    $extension = explode('.', $exp);
    $extension = $extension[count($extension)-1];
/*
    switch($extension){
        case 'js':
            ?>
            <script src="<?= $file_href ?>"></script>
            <?php
        break;
        case 'css':
            ?>
            <link rel="stylesheet" href="<?= $file_href ?>">
            <?php
        break;
        case 'gif':
        case 'jpeg':
        case 'jpg':
        case 'png':
            ?>
            <img lazy-load data-src="<?= $file_href ?>">
            <?php
        break;
        case 'svg':
            if($is_url){
                ?>
                <img src="<?= $file_href ?>">
                <?php
            } else {
                echo file_get_contents($file);
            }
        break;
        case 'mp4':
            ?>
            <video src="<?= $file_href ?>" controls></video>
            <?php
        break;
        case 'php':
            if($is_url){
                break;
            }
            try{
                include $file;
            } catch(Exception $e){
                // error_log("There was an error while loading '{$path}'.{$logInformation}");
                echo "error on: {$file}";
                return false;
            }
        break;
        default:
            // error_log("There was an error while loading '{$path}', extension not recognized.{$logInformation}");
            return false;
        break;
    }
    */
    return true;
}