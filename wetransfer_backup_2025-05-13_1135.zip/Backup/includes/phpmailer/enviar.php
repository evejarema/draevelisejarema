﻿<?php
	require("class.phpmailer.php");
	$GetParam = filter_input_array(INPUT_POST, FILTER_DEFAULT);
	
	$_username = 'send@draevelisejarema.com.br';
	$_password = '';
	$_emailRecebe = '';
	$Json['status'] = "error";
	
	switch($GetParam["trigger"]){
		case "formulario":
			$robo = $GetParam["robo"];
			$nome = $GetParam["nome"];
			$email = $GetParam["email_pessoal"];
			$telefone = $GetParam["telefone"];
			$msg = $GetParam["mensagem"];  
			$captcha = $_POST['captcha'];

			if($captcha != ''){
				$secreto = '6LeWbkopAAAAADkkt2zqiVRre_jBpA2lZtL8Dck3';
				$ip = $_SERVER['REMOTE_ADDR'];
				
				$ch = curl_init();
				curl_setopt($ch, CURLOPT_URL,"https://www.google.com/recaptcha/api/siteverify");
				curl_setopt($ch, CURLOPT_POST, 1);
				curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query(array('secret' => $secreto, 'response' => $captcha)));
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				$response = curl_exec($ch);
				curl_close($ch);
				$resposta = json_decode($response, true);
				
				$resposta['success'] = '1';
				if($resposta['success'] == "1"){
					if ($robo == "") {
						$mail = new PHPMailer();
						$mail->IsSMTP();
						$mail->Host = "mail.draevelisejarema.com.br"; 
						$mail->SMTPAuth = true;
						$mail->Username = $_username;
						$mail->Password = $_password;
						$mail->Port = 587;
						// $mail->SMTPSecure = 'tls';
						//$mail->SMTPDebug = 0;
						$mail->From = $_username;
						$mail->Sender = $_username;
						$mail->FromName = $nome;
						if($email != '' && count(explode('@', $email)) == 2){
							$mail->AddReplyTo($email);
						}
						//$mail->AddAttachment($anexo['tmp_name'], $anexo['name']);
						$mail->AddAddress($_emailRecebe);
						$mail->CharSet = 'UTF-8';
						$mail->IsHTML(true);
						$mail->Subject = "Mensagem enviada pelo site";
						$mail->Body = "<b style='font-weight:bolder'>Nome:</b> $nome <br><b style='font-weight:bolder'>Telefone:</b> $telefone <br><b style='font-weight:bolder'>Email:</b> $email <br><b style='font-weight:bolder'>Mensagem:</b> $msg";
						$enviado = $mail->Send();
						$mail->ClearAllRecipients();
						$mail->ClearAttachments();
						if ($enviado){
							$Json['status'] = "enviado";
						}else{
							$Json['status'] = "error";
						}
					}else{
						$Json['status'] = "robo";
					}
				}else{
					$Json['status'] = 'nao-autenticado';
				}
			}else{
				$Json['status'] = 'sem-captcha';
			}
		break;	
	}
	echo json_encode($Json);
?>