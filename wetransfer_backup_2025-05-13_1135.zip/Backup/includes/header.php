<?php
require 'config.inc.php';
require 'seo-config.inc.php';
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="pt-br" lang="pt-br">

<head>
    <!-- Google Tag Manager -->
    <script>
        (function (w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src =
                'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-KJZDT9FM');
    </script>
    <!-- End Google Tag Manager -->

    <meta name="facebook-domain-verification" content="wc8uxm6s62ovq96iurakk6issfb3vk" />
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=AW-11469091759"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());
        gtag('config', 'AW-11469091759');
    </script>
    <script async custom-element="amp-analytics" src="https://cdn.ampproject.org/v0/amp-analytics-0.1.js"></script>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5">
    <meta property="og:locale" content="pt_BR">
    <meta property="og:url" content="<?= HOME ?>">
    <meta property="og:title" content="<?= $PAGE_TITLE ?>">
    <meta property="og:site_name" content="<?= $PAGE_TITLE ?>">
    <meta property="og:description" content="<?= $PAGE_DESCRIPTION; ?>">
    <meta property="og:image" content="img/ogg.jpg">
    <meta property="og:image:type" content="image/jpeg">
    <meta property="og:image:width" content="800">
    <meta property="og:image:height" content="600">
    <meta property="og:type" content="website">
    <meta name="description" content="<?= $PAGE_DESCRIPTION; ?>" />
    <title><?= $PAGE_TITLE ?></title>
    <meta name="robots" content="<?= $PAGE_ROBOTS; ?>" />
    <meta name="author" content="<?= $SITE_AUTHOR ?>">
    <meta name="keywords" content="<?= $PAGE_METAKEY ?>" />
    <meta name="theme-color" content="#fff">
    <link rel="canonical" href="<?= $PAGE_URL; ?>" />

    <link rel="icon" sizes="144x144" href="css/favicon/favicon.ico" />
    <link rel="apple-touch-icon" sizes="144x144" href="css/favicon/favicon.ico" />
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="css/favicon/favicon.ico" />
    <link rel="shortcut icon" sizes="144x144" href="css/favicon/favicon.ico" />

    <link rel="stylesheet" href="css/fonts.css">
    <link rel="stylesheet" href="css/boot.css">
    <link rel="stylesheet" href="css/header.css">
    <link rel="stylesheet" href="css/footer.css" rel="onload">
    <link rel="stylesheet" href="config-slide/docs.theme.min.css">
    <link rel="stylesheet" href="config-slide/owl.carousel.min.css">
    <link rel="stylesheet" href="config-slide/owl.theme.default.min.css">
    <?php if ($URL[0]) { ?>
        <link rel="stylesheet" href="css/<?= $URL[0] ?>.css">
    <?php } ?>

    <script src="js/jquery.drag-drop.js"></script>
    <script src="config-slide/jquery.min.js"></script>
</head>

<body id="url-main" rel="<?= HOME ?>">
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KJZDT9FM" height="0" width="0"
            style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <header>
        <div class="menu-linha-top"></div>
        <div class="conteudo-center-1200">
            <div class="alinha-menu">
                <a href="<?= HOME ?>" class="logo-menu" title="<?= $PAGES_IMG_TITLES ?>"></a>
                <div class="alinha-paginas-menu">
                    <a class="item-menu link-ativo" id="link-home">Home</a>
                    <a class="item-menu" id="link-institucional">Institucional</a>
                    <a class="item-menu" id="link-servicos">Serviços</a>
                    <a class="item-menu" id="link-aparelhos">Aparelhos</a>
                    <a class="item-menu" id="link-contato">Contato</a>
                </div>

                <a class="whats" href="<?= link_whats($telefone1); ?>" target="_blank">
                    <i></i>
                    <p><?= mask('## <b>#####-####</b>', $telefone1) ?></p>
                </a>
                <a class="instagram-header" href="<?= $instagram ?>" target="_blank" title="Instagram">
                    <i></i>
                </a>
                <div class="menu-mobile">
                    <div class="menu-mobile-div">
                        <div class="menu-mobile-div-div">
                            <span></span>
                            <a class="item-menu link-ativo" id="link-home">
                                <p>Home</p>
                            </a>
                            <a class="item-menu" id="link-institucional">
                                <p>Institucional</p>
                            </a>
                            <a class="item-menu" id="link-servicos">
                                <p>Serviços</p>
                            </a>
                            <a class="item-menu" id="link-aparelhos">
                                <p>Aparelhos</p>
                            </a>
                            <a class="item-menu" id="link-contato">
                                <p>Contato</p>
                            </a>


                        </div>
                    </div>
                    <i>X</i>
                </div>
                <div class="alinha-icon-menu">
                    <a class="icon-ligar" href="tel:<?= $telefone1 ?>" title="Ligar"></a>
                    <div class="icon-menu">
                        <div class="fatia"></div>
                        <div class="fatia"></div>
                        <div class="fatia"></div>
                    </div>
                </div>
            </div>
        </div>
    </header>