<footer>
    <div class="fundo-footer link-contato">
        <div class="conteudo-center-1200">
            <div class="alinha-footer">
            <div class="infos">
                    <div class="title">Entre em contato conosco <b>hoje mesmo</b> e tire suas dúvidas!</div>
                    <div class="contato">
                        <a class="whats pc whats-href" href="<?= link_whats($telefone1); ?>" target="_blank">
                            <div class="icon whats"></div>
                            <div class="txt"><?= mask('## <b>#####-####</b>', $telefone1) ?></div>
                        </a>
                        <a class="whats mb whats-href" href="<?= link_whats($telefone1); ?>" target="_blank">
                            <div class="icon whats"></div>
                            <div class="txt"><?= mask('## <b>#####-####</b>', $telefone1) ?></div>
                        </a>
                        <a class="sub" href="mailto:<?= $email; ?>" target="_blank">
                            <div class="icon email"></div>
                            <div class="txt"><?= $email; ?></div>
                        </a>
                        <a class="sub" href="<?= $link_endereco; ?>" target="_blank">
                            <div class="icon local"></div>
                            <div class="txt"><?= $endereco; ?></div>
                        </a>
                        <div class="mais">
                            <a class="redes inst" href="<?= $instagram; ?>" target="_blank" title="Instagram"></a>
                            <a class="redes face" href="<?= $facebook; ?>" target="_blank" title="Facebook"></a>
                        </div>
                    </div>
                </div>
                <form class="formulario-footer formulario-js">
                    <input type="text" name="url" style="display: none !important" value="includes/phpmailer/">
                    <input type="text" name="email" class="display-none">
                    <input class="input-nome" type="text" name="nome" placeholder="Nome *" required="required">
                    <input class="input-email" type="email" name="email-pessoal" placeholder="E-mail">
                    <input class="input-telefone input-number" type="tel" name="telefone" placeholder="Telefone" maxlength="15">
                    <textarea name="mensagem" placeholder="Mensagem"></textarea>
                    <div class="dir">
                        <div class="container-captcha">
                            <div class="g-recaptcha" data-sitekey="6LeWbkopAAAAABu182gjcFFxUbKl7uXl8YjCHOdI"></div>
                        </div>
                        <button>Enviar</button>
                    </div>
                </form>
                

            </div>
        </div>
    </div>
    <div class="copy-sole">
        <div class="conteudo-center-1200 alinhacopy">
            <p class="c1">© 2024 • Dra. Evelise Jarema •&nbsp;</p>
            <p class="c2"><b class="desenvolvido">Desenvolvido com </b><b class="coracao">coração</b> by <a href="https://www.agenciasole.com.br" target="_blank" title="Criação de Sites em Curitiba e Desenvolvimento de Loja Virtual | E-commerce"><i>Agência Sole</i></a> | <a class="sole-vetor" href="https://www.agenciasole.com.br" target="_blank" title="Criação de Sites em Curitiba e Desenvolvimento de Loja Virtual | E-commerce">Sole</a></p>
        </div>
    </div>
</footer>

<div class="loading-js">
		<div class="engloba-loading">
			<div class="square-center">
				<div class="lds-roller">
					<div></div>
					<div></div>
					<div></div>
					<div></div>
					<div></div>
					<div></div>
					<div></div>
					<div></div>
				</div>
				<p>Aguarde</p>
			</div>
		</div>
	</div>

	<script type="application/ld+json">
		{
			"@context": "https://schema.org",
			"@type": "LocalBusiness",
			"image": "<?= HOME ?>/theme/templates/img/schema/imagem-schema-1x1.png", // criar imagem 500x500 com a logo centralizada no meio e colocar na pasta schema
			"name": "", // titulo do site
			"telephone": "", // telefone
			"address": {
				"@type": "PostalAddress",
				"streetAddress": "Rua", // endereço
				"addressLocality": "", // cidade
				"addressRegion": "", // estado
				"postalCode": "", // cep
				"addressCountry": "BR" // pais
			},
			"url": "<?= HOME ?>",
			"priceRange": "$$$" // faixa de preco, se não tiver pode tirar essa tag
		}
	</script>

	<script src="https://www.google.com/recaptcha/api.js" async defer></script>
	<?php include "includes/whats-fixo.php"; ?>
	<?php include("privacidade.php"); ?>

	<!-- Google tag (gtag.js) --> <amp-analytics type="gtag" data-credentials="include">

	</amp-analytics>

</body>

<script src="config-slide/owl.carousel.js"></script>
<script src="config-slide/highlight.js"></script>
<script src="config-slide/app.js"></script>
<script src="config-slide/viewportSize-min.js"></script>
<script src="config-slide/viewport-scale.js"></script>
<script src="js/formulario-js.js"></script>
<script src="js/whats-fixo.js"></script>
<script src="js/boot.js"></script>
<script type="application/json">
	{
		"vars": {
			"gtag_id": "AW-11469091759",
			"config": {
				"AW-11469091759": {
					"groups": "default"
				}
			}
		},
		"triggers": {}
	}
</script>

</html>