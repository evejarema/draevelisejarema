<?php
if($URL[0] != 'painel'){ ?>
<a href="<?= link_whats($telefone1); ?>" target="_blank" title="WhatsApp" class="whats-fixo whats-href" target="_blank"></a>
<style>
    .whats-fixo{position: fixed;width: 60px;height: 60px;margin: 20px;right: 0;bottom: 0;z-index: 99999;background: url('<?= HOME ?>/img/icones/whatsapp.svg') no-repeat center center, var(--whats);background-size: 30px 30px;border-radius: 50%;transition: .4s;}
    .whats-fixo:hover{box-shadow: 0 0 6px black;}
</style>
<?php
} ?>