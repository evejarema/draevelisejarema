$(window).ready(function () {
    $(".formulario-js").submit(function () {
		$(".loading-js").show();
		let dados = $(this).serializeArray();
        let url = dados[0].value;
        let robo = dados[1].value;
        let nome = dados[2].value;
        let email_pessoal = dados[3].value;
        let telefone = dados[4].value;
        let mensagem = dados[5].value;
        let captcha = dados[6].value;

        $.ajax({
			url: `includes/phpmailer/enviar.php`, data: { robo: robo, nome: nome, telefone: telefone, email_pessoal: email_pessoal, mensagem: mensagem, captcha: captcha, trigger: "formulario" }, type: "POST", dataType: "json",
			success: function (a) {
				console.log(a);
				switch (a.status) {
					case "sem-captcha":
					case "enviado":
						alert("Sua mensagem foi enviada com sucesso!! \nObrigado."),
						$(".loading-js").hide();
						// location.reload();
					break;
					case "error":
						alert("Desculpe! Sua mensagem não foi enviada. \nFavor tente novamente!");
						$(".loading-js").hide();
					break;
					case "robo":
						location.reload();
					break;
					// case "sem-captcha":
					// 	alert("Selecione o captcha para continuar.");
					// 	$(".loading-js").hide();
					// break;
					case "nao-autenticado":
						alert("Ocorreu um erro ao tentar autenticar.\nTente novamente mais tarde!");;
						$(".loading-js").hide();
					break;
				}
			},
        });
		return false;
    });
});