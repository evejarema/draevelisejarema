var owl = $(".owl-carousel");
owl.owlCarousel({
  margin: 0,
  loop: !0,
  autoplay: !0,
  autoplayTimeout: 5e3,
  nav: !0,
  dots: !0,
  items: 1,
}),
  $(".play").on("click", function () {
    owl.trigger("play.owl.autoplay", [1e3]),
      $(".play").hide(),
      $(".stop").show();
  }),
  $(".stop").on("click", function () {
    owl.trigger("stop.owl.autoplay"), $(".stop").hide(), $(".play").show();
  }),
  $(function () {
    $(".item").viewportScale({ height: "62.25vh" }),
      $(".owl-nav").viewportScale({ top: "0vh" }),
      $(".owl-prev").viewportScale({
        top: "25vh",
        width: "5vw",
        height: "10vh",
      }),
      $(".owl-next").viewportScale({
        top: "25vh",
        width: "5vw",
        height: "10vh",
      });
  }),
  $(document).ready(function () {
    $(".icon-menu").click(function () {
      $(".menu-mobile").css({ left: "0%", transition: "0.5s" });
    }),
      $(".menu-mobile i").click(function () {
        $(".menu-mobile").css({ left: "-100%", transition: "0.5s" });
      }),
      $(".menu-mobile .item-menu").click(function () {
        $(".menu-mobile").css({ left: "-100%", transition: "0.5s" });
      });
  }),
  $(window).ready(function () {
    $(".item-menu").click(function () {
      var t = $("." + $(this).attr("id").replace("#", "")).position().top;
      $("html, body").animate(
        { scrollTop: t - $("header").outerHeight() },
        500
      ),
        $(".item-menu").removeClass("link-ativo"),
        $(this).addClass("link-ativo"),
        $(".menu-mobile").css({ left: "-100%", transition: "0.5s" });
    });
  }),
  //   $(window).ready(function () {
  //     $(".input-number").keyup(function () {
  //       "14" >= `${$(this).val().length}`
  //         ? $(this).mask("(##) ####-####")
  //         : $(this).mask("(##) #####-####");
  //     });
  //   }),
  $(window).on("resize", function () {
    $(".whats-href").each(function (t, e) {
      screen.width <= 990
        ? e.setAttribute(
            "href",
            e.getAttribute("href").replace("web.whatsapp", "api.whatsapp")
          )
        : e.setAttribute(
            "href",
            e.getAttribute("href").replace("api.whatsapp", "web.whatsapp")
          );
    });
  }),
  $(window).ready(function () {
    $(window).trigger("resize");
  });
