const __ws_copy_selector = ".footer-copy, .copy-sole, .copy, .engloba-copy",
  __ws_whats_selector =
    ".whats-fixo, .whatsapp-fixo, .fixo-whatsapp, .container-contatos-flutuantes",
  __ws_politicas_selector =
    ".barra-politicas, .barra-politica, .barra-politica-cookies",
  __ws_politicas_closed_class = "barra-politicas-close",
  __ws_btnok_classes = ["btn-ok", "btn-cookies"],
  __ws_cookie_names = ["btn_ok"],
  __ws_mobile_only = !1,
  max_width = 990,
  __ws_select = (t) => document.querySelectorAll(t),
  __ws_reset_whats_attrs = async () =>
    __ws_select(__ws_whats_selector).forEach((t) => {
      t.style.transition = ".4s";
      let { offset: e, element: s } = __ws_politicas_max_height();
      "function" == typeof window.getCookie &&
        __ws_cookie_names.filter(getCookie).length > 0 &&
        __ws_overlaps(s, t) &&
        e &&
        (t.style.bottom = e + "px");
    });
async function __ws_fix_whats_height() {
  if (Math.min(screen.width, window.innerWidth) > 990)
    return __ws_reset_whats_attrs();
  let t = document.body,
    e = document.documentElement,
    s = window.scrollY,
    o = Math.max(
      t.scrollHeight,
      t.offsetHeight,
      e.clientHeight,
      e.scrollHeight,
      e.offsetHeight
    );
  o -= Math.min(screen.height, window.innerHeight);
  let i = __ws_select(".footer-copy, .copy-sole, .copy, .engloba-copy"),
    l = __ws_select(__ws_whats_selector),
    a = 0,
    { offset: n, element: c } = __ws_politicas_max_height(),
    r = (t) => {
      let e = t.getBoundingClientRect().height;
      e > a && (a = e);
    };
  i.forEach(r),
    l.forEach((t) => {
      t.style.transition || (t.style.transition = ".4s");
      let e = getComputedStyle(t),
        i = parseInt(e.marginBottom),
        l = parseInt(e.paddingBottom),
        r = i + l;
      if (__ws_overlaps(t, c, r) && n) return (t.style.bottom = n + "px");
      t.style.bottom = s + a + r >= o ? a + "px" : "";
    });
}
function __ws_politicas_max_height() {
  let t = __ws_select(
      ".barra-politicas, .barra-politica, .barra-politica-cookies"
    ),
    e = 0,
    s = null;
  return (
    t.forEach((t) => {
      if (t.classList?.contains("barra-politicas-close")) return;
      let { height: o } = t.getBoundingClientRect();
      o > e && ((e = o), (s = t));
    }),
    { offset: e, element: s }
  );
}
function __ws_overlaps(t, e, s = 0) {
  if (null == t || null == e) return !1;
  let o = t.getBoundingClientRect(),
    i = e.getBoundingClientRect();
  return !(
    o.top + s > i.bottom ||
    o.right + s < i.left ||
    o.bottom + s < i.top ||
    o.left + s > i.right
  );
}
window.addEventListener("load", () => __ws_fix_whats_height()),
  window.addEventListener("scroll", () => __ws_fix_whats_height()),
  window.addEventListener("click", (t) =>
    Array.from(t.target?.classList)?.filter((t) =>
      __ws_btnok_classes.includes(t)
    )
      ? setTimeout(__ws_fix_whats_height, 100)
      : null
  );
