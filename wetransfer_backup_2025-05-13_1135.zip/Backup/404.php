<style>
    header, footer{display:none !important}
    .erro404{background: linear-gradient(to right, #58433b, #292929); position: absolute; left: 0; top: 0; z-index: 9999; width: 100%; height: 100vh;display: flex;flex-direction: column;align-items: center;justify-content: center; }
    .erro404 p{width: 100%; text-align: center; padding: 5px 0; color: #fff}
    .erro{font: 80px montserrat-bold;}
    .aviso1{ font: 28px montserrat-medium;}
    .aviso2{ font: 30px montserrat-medium;}
</style>
<main class="erro404">
    <p class="erro">404</p>
    <p class="aviso1">Página Não Encontrada</p>
    <p class="aviso2">Você será redirecionado em <span><label id="contador">5</label></span></p>
</main>

<script src="<?= INCLUDE_PATH ?>/js/jquery.js"></script>
<script>
    addEventListener('load', (e) => {
        var contador = 5;
        function contar() {
            console.log(contador);
            document.getElementById('contador').innerHTML = contador;
            contador--;
        }
        function redirecionar() {
            contar();
            if (contador == 0) {
                document.location.href = '<?= HOME ?>';
            }
        }
        setInterval(redirecionar, 1000);
    });
</script>
