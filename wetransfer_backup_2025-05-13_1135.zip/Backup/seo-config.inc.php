<?php
$SITE_AUTHOR = 'Sole Agência Digital';
$PAGE_NAME = "Dra Evelise Jarema | Harmonização Facial e Ortodontia em Curitiba.";
$SITE_TITLE_H1 = '';
$PAGE_SITEKIT = 'img/sitekit'; 
$PAGE_METAKEY = "";
$PAGES_DESCRIPTIONS = "Dra Evelise Jarema, é especializada em profilaxia, restaurações, extração de sisos, placas de bruxismo, clareamento dental, clareamento de consultório, harmonização orofacial, preenchimento labial, preenchimento facial e bio Estimuladores, atendendo em Curitiba e região metropolitana.";
$PAGES_IMG_ALT = "";
$PAGES_IMG_TITLES ="Dra. Evelise Jarema";
$PAGES_A_TITLES =""; 

switch ($URL[0]) {
	
    case "index":
        $PAGE_TITLE = $PAGE_NAME;
        $PAGE_METAKEY = $PAGE_METAKEY;
        $PAGE_DESCRIPTION = $PAGES_DESCRIPTIONS;
        $PAGE_ROBOTS = 'index, follow';
        $PAGE_URL = HOME.'/';
        $PAGE_IMG = $PAGE_SITEKIT.'/index.png';
	break;
		
    default:       
        $PAGE_TITLE = $PAGE_NAME .'- Ooops, página não encontrada!';
        $PAGE_METAKEY = $PAGE_METAKEY;
        $PAGE_DESCRIPTION = "";
        $PAGE_ROBOTS = 'index, follow';
        $PAGE_URL = HOME.'/404';       
        $PAGE_IMG = $PAGE_SITEKIT.'/404.png';
	break;
		
	// CONFERIR SE A PAGINA DE COOKIES NÃO ESTÁ SENDO INDEXADA, O GOOGLE NÃO PODE INDEXA-LÁ...
    case "privacidade":
        $PAGE_TITLE = $PAGE_NAME;
        $PAGE_METAKEY = $PAGE_METAKEY;
        $PAGE_DESCRIPTION = $PAGES_DESCRIPTIONS;
        $PAGE_ROBOTS = 'noindex, nofollow';
        $PAGE_URL = HOME.'/';
        $PAGE_IMG = $PAGE_SITEKIT.'/index.png';
	break;
}