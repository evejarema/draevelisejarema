<?php
require 'includes/header.php';
?>
<main>
	<div class="home-demo link-home">
		<div class="row">
			<div class="large-12 columns">
				<div class="owl-carousel owl-theme">
					<?php
					$link_slide = [
						2 => "https://api.whatsapp.com/send?phone=5541998590415"
					];
					$pasta = "config-slide/slides/";
					$arquivos = glob("$pasta{*.configuracao}", GLOB_BRACE);
					foreach ($arquivos as $img) {
						$pizza = $img;
						$pieces = explode("+", $pizza);
						$link = $link_slide[$pieces[1]] ?? "";
						if ($link) {
							$pieces[2] = $link;
						}
						?>
						<div class="item img"
							style="background: url(config-slide/slides/<?php echo $pieces[1] ?>.webp) center top no-repeat;">
							<a target="_blank" title="<?= $PAGES_IMG_TITLES; ?>" <?php if ($pieces[3]) {
								  echo "href='" . '/config-slide/arquivos/' . $pieces[2] . '.' . $pieces[3] . "'";
							  }
							  if ($pieces[2]) {
								  echo "href='" . str_replace('-p-', '/', $pieces[2]) . "'";
							  } ?>
								style="background: url(config-slide/slides/chamada/<?php echo $pieces[1] ?>.webp) center no-repeat;"
								<?php if ($pieces[3]) {
									echo "de download=" . INCLUDE_PATH . '/config-slide/arquivos/' . $pieces[2] . '.' . $pieces[3] . "";
								} ?>></a>
						</div>
						<?php
					}
					?>
				</div>
				<div class="engloba-play-pause">
					<a class="button secondary play" title="Play" style="display:none"></a>
					<a class="button secondary stop" title="Stop"></a>
				</div>
			</div>
		</div>
	</div>
	<div class="engloba-infos">
		<div class="conteudo-center-1200">
			<div class="alinha-infos">
				<div class="alinha">
					<div class="title">A Dra. <b>Evelise Jarema</b></div>
					<div class="sub-title">CRO/PR 29205</div>
					<div class="txt">
						• Cirurgiã Dentista pela Universidade Federal do Paraná (UFPR)<br>
						• Pós Graduação em Cirurgia Oral Menor pela Faculdade São Leopoldo Mandic,<br>
						• Harmonização Orofacial com capacitações em preenchimentos básicos e avançados e toxina
						botulínica pela ILAPEO<br>
						• Especialista em Ortodontia pelo Instituto Odontológico das Américas (IOA)<br>
						• Credenciada Invisalign Doctor.
					</div>
				</div>
				<div class="foto-doutora" title="Dra. Evelise Jarema"
					style="background: url(img/index/dra.evelise-jarema.webp)no-repeat center var(--dourado-e);">
				</div>
			</div>
		</div>
	</div>
	<div class="engloba-diferenciais">
		<div class="conteudo-center-1200">
			<div class="alinha-diferenciais">
				<div class="engloba-img">
					<img loading="lazy" src="img/index/consultorio1.webp" alt="imagem do consultorio">
				</div>
				<div class="padrao centro">
					<div class="info">
						<div class="icon"><img loading="lazy" src="img/icones/d-ambiente.svg"
								alt="Ícone de família"></div>
						<div class="txt">Ambiente Familiar</div>
					</div>
					<div class="info">
						<div class="icon"><img loading="lazy" src="img/icones/d-tecnologia.svg"
								alt="Ícone de uma engrenagem"></div>
						<div class="txt">Tecnologia de Ponta</div>
					</div>
				</div>
				<div class="engloba-img img-maior">
					<div class="img-maior"><img loading="lazy" src="img/index/dra.evelise-jarema.webp"
							alt="Dra. Evelise Jarema"></div>
				</div>
				<div class="padrao">
					<div class="info">
						<div class="icon"><img loading="lazy" src="img/icones/d-atendimento.svg"
								alt="Ícone de coração"></div>
						<div class="txt">Atendimento Humanizado</div>
					</div>
					<div class="info">
						<div class="icon"><img loading="lazy" src="img/icones/d-equipe.svg"
								alt="Ícone de medalha"></div>
						<div class="txt">Equipe Experiente</div>
					</div>
				</div>
				<div class="engloba-img"
					style="background: url(img/index/consultorio2.webp)no-repeat center var(--dourado-e);">
					<div class="quad quad1"></div>
					<div class="quad quad2"></div>
				</div>
				<div class="padrao titulo">
					<div class="title">
						Aliando a <b>saúde</b> e <br>a <b>estética</b> visando <br>a naturalidade
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="engloba-faixa link-institucional">
		<div class="conteudo-center-1200">
			<div class="alinha-faixa">
				<div class="title">Bem-vindo ao Consultório <br>Odontológico da Dra. <b>Evelise Jarema</b></div>
				<div class="txt">
					Bem-vindo ao Consultório Odontológico da Dra. Evelise Jarema, onde a excelência em cuidados
					odontológicos encontra a dedicação ao bem-estar do paciente. Com uma abordagem personalizada, a Dra.
					Jarema e sua equipe comprometem-se em proporcionar tratamentos odontológicos de alta qualidade,
					combinando tecnologia avançada com um atendimento atencioso. Nosso consultório é um espaço acolhedor
					onde sorrisos saudáveis ganham vida, e cada paciente é recebido com cuidado e profissionalismo.
					Agende sua consulta conosco e descubra o compromisso da Dra. Evelise Jarema em transformar sorrisos
					e promover uma saúde bucal excepcional.
				</div>
			</div>
		</div>
	</div>
	<div class="engloba-aparelhos link-aparelhos">
		<div class="conteudo-center-1200">
			<div class="alinha-aparelhos">
				<div class="padrao">
					<div class="infos">
						<div class="title">
							<div class="p">Aparelho <b>Auto-Ligado</b></div>
						</div>
						<div class="linha"></div>
						<div class="txt">
							O aparelho ortodôntico auto-ligado metálico consiste em um um fio metálico que desliza sobre
							os bráckets que apresentam alta tecnologia e são considerados os aparelhos fixos de última
							geração. Seu Design dispensa o uso das “Borrachinhas” coloridas.
							<div class="grid">
								<div class="txt">
									• Movimentos mais eficientes <br>
									• Maior conforto para o paciente <br>
									• Tratamentos mais rápidos <br>
									• Acelera a movimentação dentária
								</div>
								<div class="txt">
									• Permite visitas mais espaçadas<br>
									• Melhor Higienização devido a não utilização das “Borrachinhas”<br>
									• Metálico
								</div>
							</div>
						</div>
					</div>
					<div class="img" title="Aparelho Auto-Ligado - <?= $PAGES_IMG_TITLES; ?>"><img loading="lazy"
							src="img/index/aparelho-auto-ligado.webp" alt="Imagem do aparelho ligado"></div>
				</div>
				<div class="quadrado-meio"></div>
				<div class="padrao">
					<div class="infos">
						<div class="title">
							<div class="p">Alinhadores <b>Invisalign</b></div>
						</div>
						<div class="linha"></div>
						<div class="txt">
							Invisalign, criado pela Align Technology nos Estados Unidos, conhecido como alinhador
							invisível é um tratamento ortodôntico que não usa fios metálicos. O diagnostico e a
							movimentação que vai ocorrer nos seus dentes são definidos pela Dra Evelise, com alta
							tecnologia que utiliza o escaneamento intraoral para o planejamento do seu sorriso.<br><br>
							Te permite maior liberdade em eventos sociais e práticas esportivas porque são discretos.
							Facilidade em higienizar.<br><br>
							Na primeira consulta são realizados o diagnóstico inicial e os exames que serão necessários
							para realizar o tratamento.
						</div>
					</div>
					<div class="img" title="Alinhadores Invisalign - <?= $PAGES_IMG_TITLES; ?>"><img loading="lazy"
							src="img/index/aparelho-invisalign.webp" alt="Imagem do aparelho na caixa"></div>
				</div>
			</div>
		</div>
	</div>
	<div class="engloba-como">
		<div class="conteudo-center-1200">
			<div class="alinha-como">
				<div class="padrao esq">
					<div class="title">Como <b>Funciona?</b></div>
					<div class="txt">O tratamento com o aparelho é feito de maneira progressiva, alcançando resultados
						rapidamente e com o máximo conforto. Funciona com o uso de uma sequência de alinhadores
						personalizados para cada paciente. Eles são feitos de um material muito confortável e
						confeccionados após um planejamento bem detalhado.</div>
				</div>
				<div class="padrao dir">
					<div class="title">Benefícios do <b>Invisalign</b></div>
					<div class="grid">
						<div class="txt">
							• Previsibilidade do tratamento<br>
							• Conforto para o paciente<br>
							• Mantém a estética do sorriso
						</div>
						<div class="txt">
							• Resultados mais rápidos<br>
							• Alinhadores discretos<br>
							• Mais praticidade
						</div>
					</div>
					<a class="btn whats-href" href="<?= link_whats($telefone1); ?>" target="_blank"><i></i>
						<p>Nos envie um WhatsApp</p>
					</a>
				</div>
			</div>
		</div>
	</div>
	<div class="engloba-servicos link-servicos">
		<div class="conteudo-center-1200">
			<div class="alinha-servicos title">
				<div class="title">Serviços <b>Ofertados</b></div>
			</div>
			<div class="alinha-servicos servicos">
				<?php
				$Servicos = [
					[
						'titulo' => 'Profilaxia',
						'icone' => 'img/servicos/profilaxia.svg'
					],
					[
						'titulo' => 'Restaurações',
						'icone' => 'img/servicos/restauracoes.svg'
					],
					[
						'titulo' => 'Extração<br> de Sisos',
						'icone' => 'img/servicos/extracao-de-sisos.svg'
					],
					[
						'titulo' => 'Placas de<br> Bruxismo',
						'icone' => 'img/servicos/placas-de-bruxismo.svg'
					],
					[
						'titulo' => 'Preenchimento<br> Facial',
						'icone' => 'img/servicos/preenchimento-facial.svg'
					],
					[
						'titulo' => 'Clareamento<br> Dental',
						'icone' => 'img/servicos/clareamento-dental.svg'
					],
					[
						'titulo' => 'Clareamento<br> de Consultório',
						'icone' => 'img/servicos/clareamento-de-consultorio.svg'
					],
					[
						'titulo' => 'Harmonização<br> Orofacial',
						'icone' => 'img/servicos/harmonizacao-orofacial.svg'
					],
					[
						'titulo' => 'Preenchimento<br> Labial',
						'icone' => 'img/servicos/preenchimento-labial.svg'
					],
					[
						'titulo' => 'Bioestimuladores',
						'icone' => 'img/servicos/bioestimuladores.svg'
					],
				];

				foreach ($Servicos as $servico) { ?>
					<div class="padrao">
						<div class="txt">
							<p><i>• </i><?= $servico['titulo'] ?></p>
						</div>
					</div>
					<?php
				} ?>
			</div>
		</div>
	</div>
	<div class="engloba-sorrir">
		<div class="conteudo-center-1200">
			<div class="alinha-sorrir">
				<div class="sombra"></div>
				<div class="title"><b>Sorrisos saudáveis</b> com cuidados odontológicos <b>excepcionais!</b></div>
			</div>
		</div>
	</div>
</main>
<?php require 'includes/footer.php'; ?>