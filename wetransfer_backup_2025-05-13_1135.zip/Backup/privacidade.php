<div class="bloco-politicas-cookies">
	<div class="container-politicas <?php if($URL[0] == 'privacidade') { echo 'abrir-politicas'; } ?>">
		<div class="titulo-politicas">
			<p>POLÍTICA DE COOKIES</p>
		</div>
		<p class="txt-politicas">
			Atualizado em 08 de janeiro de 2024.
		</p>
		<p class="txt-politicas">
			Com a aceitação dos termos da Política de Privacidade de nosso site o usuario/visitante, por meio do botão ACEITO, concorda com as disposições estabelecidas.
		</p>
		<p class="txt-politicas">
			O presente termo tem por finalidade esclarecer regras para utilização de dados que incluem mecanismo de acesso, reprodução, arquivamento, processamento, armazenamento, recepção, classificação, utilização, coleta dos dados dos usuários, além do registro das atividades do usuário dentro do domínio.
		</p>
		<p class="txt-politicas">
			Armazenamos os dados dos usuários que nos são fornecidos, direta ou indiretamente, durante a utilização de nosso site e aplicativos por meio e cookies, tecnologia que pode perceber e receber informações do usuário com intuito de otimizar sua experiencia em nosso site.
		</p>
		<p class="txt-politicas">
			Os dados que poderão ser armazenados são: links e botões clicados, paginas visitadas, endereço IP, informações a respeito do navegador, sistema operacional do dispositivo, resolução da tela, gênero, não se limitando a estes, bem como os dados fornecidos por meio de preenchimento formulários.
		</p>
		<p class="txt-politicas">
			Não nos responsabilizamos pela veracidade ou imprecisão dos dados fornecidos pelo usuário. Nosso site utiliza cookies e demais identificadores anônimos para otimização da navegação, segurança e análise de publicidade.
		</p>
		<p class="txt-politicas">
			O termo de vigência durante a sessão e também permanentes, cujos dados podem ser utilizados no intuito de lembrar informações de contato no formulário do site para facilitar o seu preenchimento.
		</p>
		<p class="txt-politicas">
			Os dados dos usuários poderão ser utilizados com as finalidades de identificação, manutenção de cadastro atualizado para fins de contatos por mensagens e newslatter (com autorização dos usuários) (e-mail, aplicativos e redes sociais), realização de estatísticas e estudos destinados a análise de comportamentos de forma anônima, promoção de conteúdos, anúncios de produtos e/ou serviços.
		</p>
		<p class="txt-politicas">
			A utilização dos dados e de sua base são realizados nos limites e destinação das atividades do titular do site, não são repassados ou compartilhados com terceiros.
		</p>
		<p class="txt-politicas">
			O usuário concorda que o titular do site poderá utilizar os dados que lhe forem confiados durante a navegação de como forma a otimizar seus serviços com o compromisso de que os dados somente serão acessados pelo titular do site e dos profissionais devidamente autorizados com a finalidade e propósito do site.
		</p>
		<p class="txt-politicas">
			Os dados serão armazenados em local seguro, em servidor próprio ou de terceiros, dentro do período de vigência da concordância, sendo que, fica o usuário ciente que nenhum sistema de segurança é inviolável, ficando isento o titular do site de possíveis danos ou prejuízos decorrentes de atuação de terceiros ou vírus, salvo nos casos de dolo do titular do site.
		</p>
		<p class="txt-politicas">
			Em caso de denúncias e dúvidas o usuário poderá entrar em contato com as informações presentes no site.
		</p>

		<div class="engloba-btn-voltar">
			<a class="btn-voltar-2" href="<?= HOME ?>">
				<p>VOLTAR</p>
			</a>
		</div>
	</div>
	<div class="barra-politicas">
		<div class="fundo-barra-politicas"></div>		
		<div class="txt-barra-termo">Nós utilizamos cookies para personalizar sua experiência. Ao acessar o site, você concorda com a nossa <a class="open-politicas" href="<?= HOME ?>/privacidade" target="_blank">política de privacidade</a>. <i class="btn-ok">OK</i></div>
	</div>
</div>
<style> 
	.bloco-politicas-cookies{}
	.bloco-politicas-cookies .container-politicas{ display: none; width: 100%; height: 100%; float: left; background: #fff; position: fixed; top: 0; left: 0; z-index: 999999; overflow: auto;}
	.bloco-politicas-cookies .container-politicas.abrir-politicas{ display: block;}
	.bloco-politicas-cookies .container-politicas .titulo-politicas { width: 100%; float: left; margin: 40px 0 40px; text-align: center; display: flex; justify-content: center;}
	.bloco-politicas-cookies .container-politicas .titulo-politicas p { float: left; font: 20px arial; color: #fff; text-align: center; font-weight: bold; background: #333; padding: 30px 50px; border-radius: 10px; margin: 0;}
	.bloco-politicas-cookies .container-politicas .txt-politicas { width: 90%; float: left; font: 16px arial; color: #656565; line-height: 22px; text-align: justify; margin: 0 5% 20px;}
	.bloco-politicas-cookies .container-politicas .engloba-btn-voltar{ width: 100%; float: left; display: flex; align-items: center; justify-content: center;}
	.bloco-politicas-cookies .container-politicas .engloba-btn-voltar .btn-voltar-2{ width: 150px; height: 45px; float: left; background: #1bad00; border-radius: 5px; display: flex; align-items: center; margin: 0 0 40px 0; cursor: pointer;}
	.bloco-politicas-cookies .container-politicas .engloba-btn-voltar .btn-voltar-2 p{ width: 100%; float: left; font: 12px arial; color: #fff; text-align: center; font-weight: bold;}
	.bloco-politicas-cookies .barra-politicas{ display: none; width: 100%; float: left; position: fixed; bottom: 0; left: 0; z-index: 9999;}
	.bloco-politicas-cookies .barra-politicas.barra-politicas-open{ display: block !important;}
	.bloco-politicas-cookies .barra-politicas.barra-politicas-close{ display: none !important;}
	.bloco-politicas-cookies .barra-politicas .fundo-barra-politicas{ width: 100%; height: 100%; position: absolute; top: 0; left: 0; background: #e6e6e6 }
	.bloco-politicas-cookies .barra-politicas .txt-barra-termo{ width: 96%; float: left; font: 16px arial; color: #5f5f5f; line-height: 35px; padding: 20px 0; position: relative; z-index: 9999; margin: 0 2%; text-align: center;}
	.bloco-politicas-cookies .barra-politicas .txt-barra-termo i{ background: #008a00; padding: 6px 35px; margin: 0 0 0 10px; border-radius: 5px; cursor: pointer; font-size: 14px; color: #fff}
	.bloco-politicas-cookies .barra-politicas .txt-barra-termo i:hover{ background: #014801;}
	.bloco-politicas-cookies .barra-politicas .txt-barra-termo .open-politicas{ text-decoration: underline; cursor: pointer; color: #5f5f5f}
	
	@media (max-width: 990px){
		.bloco-politicas-cookies .container-politicas .titulo-politicas { margin: 20px 0;}
		.bloco-politicas-cookies .container-politicas .titulo-politicas p { font-size: 14px; padding: 20px 30px;}
		.bloco-politicas-cookies .container-politicas .txt-politicas { font-size: 14.5px; line-height: 22px;}
		.bloco-politicas-cookies .barra-politicas .txt-barra-termo { width: 80%; margin: 10px 10%; font-size: 13px; line-height: 20px; padding: 0; text-align: center; color: #5f5f5f}
		.bloco-politicas-cookies .barra-politicas .txt-barra-termo i { display: inline-block; margin: 10px 0 0 0; width: 100%; height: auto; padding: 6px 0; border-radius: 5px; font-size: 12px; background: #008a00; color: #fff; float: left;}
		.bloco-politicas-cookies .barra-politicas.barra-politicas-open { left: 0; bottom: 0; width: 100%; padding: 0;}
	}
</style>
<script>
    $(window).ready(function() { 
        $(document).on("click", ".btn-ok, main, header, footer", function() {
            var d = new Date();
            d.setTime(d.getTime() + (7 * 24 * 60 * 60 * 1000));
            var expires = "expires=" + d.toUTCString();
            document.cookie = "btn_ok=ok" + ";" + expires + ";path=/";
            $('.barra-politicas').addClass('barra-politicas-close');
        });
    });
    function getCookie(cname) {
        var name = cname + "=";
        var decodedCookie = decodeURIComponent(document.cookie);
        var ca = decodedCookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') {
                c = c.substring(1);
            }
            if (c.indexOf(name) == 0) {
                return c.substring(name.length, c.length);
            }
        }
        return "";
    }
    checkCookie();
    function checkCookie() {
        var user = getCookie("btn_ok");
        
        if (user == "") {
            $('.barra-politicas').addClass('barra-politicas-open');
        }
    }
</script>